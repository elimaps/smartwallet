# Signin-Signup Form using React

This project is a simple implementation of a Signin-Signup form built using React. 


## Installation

To run this project locally, follow these steps:

1. Clone this repository to your local machine:
   
git clone [<repository-url>](https://github.com/arjungautam1/Signin-Signup.git)https://github.com/arjungautam1/Signin-Signup.git

2. npm install
3. npm start 
